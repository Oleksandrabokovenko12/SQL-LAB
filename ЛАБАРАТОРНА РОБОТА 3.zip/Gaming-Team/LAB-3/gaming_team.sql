-- Лабораторна робота 3. Фізична модель gaming_team.
-- MySQL 8.0.16+ / InnoDB / utf8mb4.
-- Виконуйте один раз у новій порожній схемі; DROP не використовується.
CREATE DATABASE IF NOT EXISTS `gaming_team`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `gaming_team`;

CREATE TABLE `game` (
  `game_id` INT NOT NULL AUTO_INCREMENT,
  `game_title` VARCHAR(100) NOT NULL,
  `genre` VARCHAR(50) NOT NULL,
  `platform` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`game_id`),
  CONSTRAINT `uq_game_1` UNIQUE (`game_title`, `platform`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `player` (
  `player_id` INT NOT NULL AUTO_INCREMENT,
  `nickname` VARCHAR(50) NOT NULL,
  `first_name` VARCHAR(50) NOT NULL,
  `last_name` VARCHAR(50) NOT NULL,
  `birth_date` DATE NOT NULL,
  `country` VARCHAR(60) NOT NULL,
  PRIMARY KEY (`player_id`),
  CONSTRAINT `uq_player_1` UNIQUE (`nickname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `team` (
  `team_id` INT NOT NULL AUTO_INCREMENT,
  `game_id` INT NOT NULL,
  `team_name` VARCHAR(100) NOT NULL,
  `country` VARCHAR(60) NOT NULL,
  `founded_on` DATE NOT NULL,
  `contact_email` VARCHAR(254) NOT NULL,
  PRIMARY KEY (`team_id`),
  INDEX `idx_team_game_id` (`game_id`),
  CONSTRAINT `fk_team_game_id` FOREIGN KEY (`game_id`)
    REFERENCES `game` (`game_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `membership` (
  `membership_id` INT NOT NULL AUTO_INCREMENT,
  `player_id` INT NOT NULL,
  `team_id` INT NOT NULL,
  `joined_on` DATE NOT NULL,
  `left_on` DATE NULL,
  `role` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`membership_id`),
  CONSTRAINT `uq_membership_1` UNIQUE (`player_id`, `team_id`, `joined_on`),
  INDEX `idx_membership_player_id` (`player_id`),
  CONSTRAINT `fk_membership_player_id` FOREIGN KEY (`player_id`)
    REFERENCES `player` (`player_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  INDEX `idx_membership_team_id` (`team_id`),
  CONSTRAINT `fk_membership_team_id` FOREIGN KEY (`team_id`)
    REFERENCES `team` (`team_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ck_membership_1` CHECK (left_on IS NULL OR left_on >= joined_on)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `tournament` (
  `tournament_id` INT NOT NULL AUTO_INCREMENT,
  `game_id` INT NOT NULL,
  `tournament_name` VARCHAR(150) NOT NULL,
  `starts_on` DATE NOT NULL,
  `ends_on` DATE NOT NULL,
  `prize_pool` DECIMAL(14,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tournament_id`),
  INDEX `idx_tournament_game_id` (`game_id`),
  CONSTRAINT `fk_tournament_game_id` FOREIGN KEY (`game_id`)
    REFERENCES `game` (`game_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ck_tournament_1` CHECK (ends_on >= starts_on),
  CONSTRAINT `ck_tournament_2` CHECK (prize_pool >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `game_match` (
  `match_id` INT NOT NULL AUTO_INCREMENT,
  `tournament_id` INT NOT NULL,
  `scheduled_at` DATETIME NOT NULL,
  `match_format` VARCHAR(10) NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'scheduled',
  PRIMARY KEY (`match_id`),
  INDEX `idx_game_match_tournament_id` (`tournament_id`),
  CONSTRAINT `fk_game_match_tournament_id` FOREIGN KEY (`tournament_id`)
    REFERENCES `tournament` (`tournament_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  INDEX `idx_game_match_extra_1` (`scheduled_at`),
  CONSTRAINT `ck_game_match_1` CHECK (match_format IN ('BO1', 'BO3', 'BO5')),
  CONSTRAINT `ck_game_match_2` CHECK (status IN ('scheduled', 'ongoing', 'completed', 'cancelled'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `match_team` (
  `match_id` INT NOT NULL,
  `team_id` INT NOT NULL,
  `score` INT NULL,
  `outcome` VARCHAR(10) NULL,
  PRIMARY KEY (`match_id`, `team_id`),
  INDEX `idx_match_team_match_id` (`match_id`),
  CONSTRAINT `fk_match_team_match_id` FOREIGN KEY (`match_id`)
    REFERENCES `game_match` (`match_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  INDEX `idx_match_team_team_id` (`team_id`),
  CONSTRAINT `fk_match_team_team_id` FOREIGN KEY (`team_id`)
    REFERENCES `team` (`team_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ck_match_team_1` CHECK (score IS NULL OR score >= 0),
  CONSTRAINT `ck_match_team_2` CHECK (outcome IS NULL OR outcome IN ('win', 'loss'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

