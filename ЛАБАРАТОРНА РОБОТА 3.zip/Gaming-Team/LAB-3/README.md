# Лабораторна робота 3
## Фізична модель інформаційної системи геймерської команди

### Мета
Перетворити логічну модель з лабораторної №2 на фізичну модель: визначити таблиці, типи даних, PK, FK, обов’язковість полів, індекси та створити SQL-скрипт.

### Результат
Створено **7 таблиць**, **37 стовпців** та **7 зовнішніх ключів**. СУБД — MySQL 8.0.16+; рушій InnoDB; кодування utf8mb4; зіставлення utf8mb4_unicode_ci.

![Фізична модель](gaming_team_physical.drawio.png)

[Файл draw.io](gaming_team_physical.drawio) · [SQL-скрипт](gaming_team.sql) · [DBML-модель](gaming_team.dbml)

Діаграма містить усі стовпці, фізичні типи та позначення PK/FK/NN/NULL/AI. Стрілки йдуть від FK до батьківського PK. Для необов’язкового FK батьківський запис може бути відсутній; цифри N і 1 показують максимальну кратність.

### Специфікація стовпців
| Таблиця | Поле | Тип | Ключ | Обов’язковість / значення за замовчуванням |
|---|---|---|---|---|
| game | game_id | INT | PK  | NOT NULL AUTO_INCREMENT |
| game | game_title | VARCHAR(100) |  | NOT NULL |
| game | genre | VARCHAR(50) |  | NOT NULL |
| game | platform | VARCHAR(50) |  | NOT NULL |
| player | player_id | INT | PK  | NOT NULL AUTO_INCREMENT |
| player | nickname | VARCHAR(50) |  | NOT NULL |
| player | first_name | VARCHAR(50) |  | NOT NULL |
| player | last_name | VARCHAR(50) |  | NOT NULL |
| player | birth_date | DATE |  | NOT NULL |
| player | country | VARCHAR(60) |  | NOT NULL |
| team | team_id | INT | PK  | NOT NULL AUTO_INCREMENT |
| team | game_id | INT | FK  | NOT NULL |
| team | team_name | VARCHAR(100) |  | NOT NULL |
| team | country | VARCHAR(60) |  | NOT NULL |
| team | founded_on | DATE |  | NOT NULL |
| team | contact_email | VARCHAR(254) |  | NOT NULL |
| membership | membership_id | INT | PK  | NOT NULL AUTO_INCREMENT |
| membership | player_id | INT | FK  | NOT NULL |
| membership | team_id | INT | FK  | NOT NULL |
| membership | joined_on | DATE |  | NOT NULL |
| membership | left_on | DATE |  | NULL |
| membership | role | VARCHAR(50) |  | NOT NULL |
| tournament | tournament_id | INT | PK  | NOT NULL AUTO_INCREMENT |
| tournament | game_id | INT | FK  | NOT NULL |
| tournament | tournament_name | VARCHAR(150) |  | NOT NULL |
| tournament | starts_on | DATE |  | NOT NULL |
| tournament | ends_on | DATE |  | NOT NULL |
| tournament | prize_pool | DECIMAL(14,2) |  | NOT NULL DEFAULT 0 |
| game_match | match_id | INT | PK  | NOT NULL AUTO_INCREMENT |
| game_match | tournament_id | INT | FK  | NOT NULL |
| game_match | scheduled_at | DATETIME |  | NOT NULL |
| game_match | match_format | VARCHAR(10) |  | NOT NULL |
| game_match | status | VARCHAR(20) |  | NOT NULL DEFAULT 'scheduled' |
| match_team | match_id | INT | PK FK  | NOT NULL |
| match_team | team_id | INT | PK FK  | NOT NULL |
| match_team | score | INT |  | NULL |
| match_team | outcome | VARCHAR(10) |  | NULL |

### Зовнішні ключі
| Зовнішній ключ | Батьківський ключ | Видалення / оновлення |
|---|---|---|
| team.game_id | game.game_id | RESTRICT / RESTRICT |
| membership.player_id | player.player_id | RESTRICT / RESTRICT |
| membership.team_id | team.team_id | RESTRICT / RESTRICT |
| tournament.game_id | game.game_id | RESTRICT / RESTRICT |
| game_match.tournament_id | tournament.tournament_id | RESTRICT / RESTRICT |
| match_team.match_id | game_match.match_id | RESTRICT / RESTRICT |
| match_team.team_id | team.team_id | RESTRICT / RESTRICT |

### Запуск скрипту
1. Відкрийте MySQL Workbench і підключіться до свого MySQL-сервера.
2. Виберіть File → Open SQL Script та відкрийте `gaming_team.sql`.
3. Запустіть скрипт повністю. Він створить базу `gaming_team` та її таблиці.
4. Оновіть SCHEMAS. Для перевірки виконайте:

```sql
USE gaming_team;
SHOW TABLES;
SHOW CREATE TABLE `match_team`;
```

Скрипт призначений для першого запуску у порожній схемі. Він не видаляє дані та не змінює існуючі таблиці. Повторне виконання CREATE TABLE для існуючої таблиці завершиться помилкою; для повторного запуску використайте іншу порожню схему.

Для отримання діаграми у власному середовищі виконайте reverse engineering створеної схеми у MySQL Workbench. До комплекту вже додано редаговану діаграму draw.io. Файли сформовано програмно; це не скріншоти DBDesigner і не експорт із нього. SQL є основним джерелом визначень; DBML — додатковий формат із типами та зв’язками, без дублювання всіх CHECK та DEFAULT.

### Чому обрано ці типи
INT використано для сумісних PK та FK. VARCHAR — для тексту; DATE — для календарних дат; DATETIME — для дати й часу події. DECIMAL зберігає грошові суми точно. AUTO_INCREMENT генерує сурогатні ідентифікатори; у зв’язувальній таблиці зі складеним PK він не потрібен. FK індексуються явно; UNIQUE та PK також створюють індекси.

### Перехід від лабораторної 2
П’ять основних сутностей збережено. Зв’язок membership із власними атрибутами став окремою таблицею; зв’язок plays перетворено на match_team. Таблиця match_team має складений PK(match_id, team_id), який забороняє дублювання команди в одному матчі. membership_id дає змогу зберігати повторні приєднання гравця до тієї самої команди.

Усі раніше визначені атрибути збережено. scheduled_at фізично реалізовано DATETIME із домовленістю зберігати UTC. prize_pool — USD. Роль гравця — текст, оскільки назви ролей залежать від гри. UNIQUE(game_title, platform), UNIQUE(nickname) та UNIQUE(player_id, team_id, joined_on) фіксують обрані кандидатні ключі.

CHECK перевіряють порядок дат турніру і членства, невід’ємні призові й рахунок, допустимі BO1/BO3/BO5, статуси та win/loss. Перевірка рівно двох команд перед початком матчу, сумісності ігор, відсутності перетинів членства, дат матчів у межах турніру та узгодженості підсумкового рахунку потребує міжрядкової транзакційної логіки. Цей DDL не реалізує ці правила тригерами; вони залишаються специфікацією для застосунку. Наявність FK сама по собі їх не гарантує.

### Перевірка і межі перевірки
Таблиці, стовпці, PK і FK зіставлено між SQL та діаграмою. Додатково проведено локальні перевірки обмежень на SQLite після технічного перетворення MySQL DDL; докладні результати містяться у verification.md. MySQL-сервер у робочому середовищі відсутній, тому успішний імпорт саме у MySQL не заявляється. Після імпорту перевірте SHOW TABLES та SHOW CREATE TABLE.

### Висновок
Побудовано фізичну модель з конкретними типами, первинними та зовнішніми ключами. Додано індекси для зв’язків і пошуку за часом, а також обмеження цілісності рівня рядка. SQL-скрипт готовий для першого запуску у порожній схемі MySQL; діаграму можна редагувати у draw.io.

### Джерела
- Надана методичка Lab 3.pdf, слайди 2–4, 12–16.
- [MySQL CREATE TABLE](https://dev.mysql.com/doc/refman/8.4/en/create-table.html).
- [MySQL CHECK constraints](https://dev.mysql.com/doc/refman/8.0/en/create-table-check-constraints.html).

### Завантаження на GitHub
Завантажте весь вміст цієї папки до LAB-3 відповідного репозиторію. README.md, PNG, drawio, DBML та SQL повинні залишатися разом, щоб відносні посилання працювали.
